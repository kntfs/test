/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/
window.addEventListener('DOMContentLoaded', (event) => {

  const nav = document.getElementById('navbar__list');
  // Global variable decleared for all sections 
  const sections = document.querySelectorAll('section');
  
  const navBuilder = () => {
      let navUI = '';
      // loop to iterate through different sections
      sections.forEach(section => {
          const sectionId = section.id;
          const sectionNavigatorData = section.dataset.nav;
  
          navUI += `<li><a class="menu__link" href="#${sectionId}">${sectionNavigatorData}</a></li>`;
      });
      // Here elements will be appended to the navigation section
      nav.innerHTML = navUI;
  };
  
  navBuilder();
  
  // Add class 'active' to section when near top of viewport
  
  const activeSection = (section) => {
      return Math.floor(section.getBoundingClientRect().top);
  };
  
  
  const addActiveClass = (condition,section) => {
      if(condition) {
          section.classList.add('your-active-class');
      };
  };
  
  const removeActiveClass =(section) => {
      section.classList.remove('your-active-class');
  };
  
  const sectionActivation = () => {
      sections.forEach(section => {
          const elementOffset = activeSection(section);
  
          viewPort = () => elementOffset < 180 && elementOffset >= -180;
          removeActiveClass(section);
          addActiveClass(viewPort(),section);
      });
  };
  
  window.addEventListener('scroll',sectionActivation);
  


  // smooth scroll - https://www.w3schools.com/

  $(document).ready(function(){
    $("a").on('click', function(event) {
      if (this.hash !== "") {
        event.preventDefault();
  
        var hash = this.hash;
  
        $(".menu__link").removeClass("menu__link--active");
        $(this).addClass("menu__link--active");
                    
        $('html, body').animate({
          scrollTop: $(hash).offset().top
        }, 800, function(){
          window.location.hash = hash;
        });
      } 
    });
  });



});
