#ABOUT THE PROJECT
This is my second project for the Frontend Nanodegree Program.
This project is to make a dynamic landing page using Javascript.


#LANGUGAE USED
• HTML
• CSS
• JAVASCRIPT

 
#FUCTIONALITIES 
• To add dynamic effect
• To add scrolling effect
• and some navigation related effects

 
#HOW TO ACCESS 
• Navigate to the folder in which you have saved/downloded project
• Select the index.html file
• Open the indexd.html using the browsers(like Google Chrome, Mozilla Firefox, Microsoft Edge, Safari, etc.)
• You can see the Javascript's effects on this project


#OUTCOME OF THE PROJECT
To learn how to turn a static web page into dynamic one using Javascript.
